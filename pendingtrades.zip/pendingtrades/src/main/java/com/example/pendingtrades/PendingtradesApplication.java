package com.example.pendingtrades;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PendingtradesApplication {

	public static void main(String[] args) {
		SpringApplication.run(PendingtradesApplication.class, args);
	}

}
