import software.amazon.awssdk.auth.credentials.ProfileCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Request;
import software.amazon.awssdk.services.s3.model.ListObjectsV2Response;
import software.amazon.awssdk.services.s3.model.S3Object;

import java.io.File;
import java.nio.file.Paths;

public class S3Downloader {
    private static final Region REGION = Region.US_WEST_2;  // Adjust region
    private static final S3Client s3Client = S3Client.builder()
            .region(REGION)
            .credentialsProvider(ProfileCredentialsProvider.create())
            .build();

    public static void downloadFile(String bucketName, String key, String downloadPath) {
        GetObjectRequest getObjectRequest = GetObjectRequest.builder()
                .bucket(bucketName)
                .key(key)
                .build();
        s3Client.getObject(getObjectRequest, Paths.get(downloadPath));
        System.out.println("Downloaded: " + key);
    }

    public static void downloadFilesWithPrefix(String bucketName, String folderPrefix) {
        ListObjectsV2Request listRequest = ListObjectsV2Request.builder()
                .bucket(bucketName)
                .prefix(folderPrefix)
                .build();

        ListObjectsV2Response listResponse = s3Client.listObjectsV2(listRequest);
        for (S3Object object : listResponse.contents()) {
            String key = object.key();
            String fileName = key.substring(key.lastIndexOf('/') + 1);
            downloadFile(bucketName, key, "downloads/" + fileName);
        }
    }
}
