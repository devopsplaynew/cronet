import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        String bucketName = "your-bucket-name";
        String folderPrefix = "your-folder-prefix";  // E.g., "your-folder/"

        // Step 1: Download files from S3
        S3Downloader.downloadFilesWithPrefix(bucketName, folderPrefix);

        // Step 2: Prepare downloaded files for email
        List<File> attachments = new ArrayList<>();
        File downloadDir = new File("downloads");
        if (downloadDir.exists() && downloadDir.isDirectory()) {
            for (File file : downloadDir.listFiles()) {
                attachments.add(file);
            }
        }

        // Step 3: Send email with attachments
        EmailSender.sendEmailWithAttachments(
                "recipient@example.com",
                "S3 Downloaded Files",
                "Attached are the files downloaded from S3.",
                attachments
        );

        // Optional: Cleanup downloaded files
        for (File file : attachments) {
            file.delete();
        }
    }
}
