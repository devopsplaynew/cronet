# ATLS + ADM Combined API

This project is a Spring Boot (Java 17) application that connects to two PostgreSQL databases (ATLS and ADM),
executes the provided SQL queries, and returns a combined JSON response.

## What is included
- Maven project
- Two datasource configurations (`atls` and `adm`)
- Repository that reads SQL from `src/main/resources/sql/`
- Service and Controller exposing `/api/combined-results`
- SQL files: `sql/atls.sql` and `sql/adm.sql`

## How to use
1. Install Java 17 and Maven.
2. Edit `src/main/resources/application.yml` and replace placeholders with your DB credentials.
3. Build:
   ```bash
   mvn clean package
   ```
4. Run:
   ```bash
   java -jar target/atls-adm-combined-api-0.0.1-SNAPSHOT.jar
   ```
5. Call the API:
   ```
   GET http://localhost:8080/api/combined-results
   ```

## Security note
Do NOT paste database credentials into public chat. Edit `application.yml` locally or use environment variables / vault.

