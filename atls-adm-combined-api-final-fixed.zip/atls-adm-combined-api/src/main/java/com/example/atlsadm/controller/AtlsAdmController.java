package com.example.atlsadm.controller;

import com.example.atlsadm.service.AtlsAdmService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@RestController
@RequestMapping("/api")
public class AtlsAdmController {

    private final AtlsAdmService service;

    public AtlsAdmController(AtlsAdmService service) {
        this.service = service;
    }

    @GetMapping("/")
    public String home() {
        return "Welcome to ATLS-ADM Combined API. Use /api/combined-data to get the combined JSON.";
    }

    @GetMapping("/combined-data")
    public Map<String, Object> getCombinedData() {
        return service.getCombinedData();
    }
}
