package com.example.atlsadm.repository;

import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.util.StreamUtils;

@Repository
public class CombinedDataRepository {

    private final JdbcTemplate atlsJdbc;
    private final JdbcTemplate admJdbc;

    public CombinedDataRepository(@Qualifier("atlsJdbcTemplate") JdbcTemplate atlsJdbc,
                                  @Qualifier("admJdbcTemplate") JdbcTemplate admJdbc) {
        this.atlsJdbc = atlsJdbc;
        this.admJdbc = admJdbc;
    }

    private String loadSql(String path) {
        try {
            ClassPathResource r = new ClassPathResource(path);
            return StreamUtils.copyToString(r.getInputStream(), StandardCharsets.UTF_8);
        } catch (Exception ex) {
            throw new RuntimeException("Failed to load SQL: " + path, ex);
        }
    }

    public List<Map<String, Object>> fetchAtlsData() {
        String sql = loadSql("sql/atls.sql");
        return atlsJdbc.queryForList(sql);
    }

    public List<Map<String, Object>> fetchAdmData() {
        String sql = loadSql("sql/adm.sql");
        return admJdbc.queryForList(sql);
    }
}
