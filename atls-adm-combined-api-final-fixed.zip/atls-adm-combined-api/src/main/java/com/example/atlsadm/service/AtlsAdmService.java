package com.example.atlsadm.service;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Duration;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
public class AtlsAdmService {

    private final JdbcTemplate admJdbcTemplate;
    private final JdbcTemplate atlsJdbcTemplate;

    public AtlsAdmService(@Qualifier("admJdbcTemplate") JdbcTemplate admJdbcTemplate,
                          @Qualifier("atlsJdbcTemplate") JdbcTemplate atlsJdbcTemplate) {
        this.admJdbcTemplate = admJdbcTemplate;
        this.atlsJdbcTemplate = atlsJdbcTemplate;
    }

    private static final DateTimeFormatter TS_FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").withZone(ZoneId.systemDefault());
    private static final SimpleDateFormat DATE_ONLY = new SimpleDateFormat("yyyy-MM-dd");

    public Map<String, Object> getCombinedData() {
        String admSql = readResourceSql("sql/adm.sql");
        String atlsSql = readResourceSql("sql/atls.sql");

        List<Map<String, Object>> admData = admJdbcTemplate.query(admSql, (rs, rowNum) -> mapRow(rs));
        List<Map<String, Object>> atlsData = atlsJdbcTemplate.query(atlsSql, (rs, rowNum) -> mapRow(rs));

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("admData", admData);
        result.put("atlsData", atlsData);
        result.put("timestamp", new Date());
        return result;
    }

    private Map<String, Object> mapRow(ResultSet rs) throws SQLException {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("process_type", safeGetString(rs, "process_type"));
        m.put("client_cd", safeGetString(rs, "client_cd"));
        m.put("processing_region_cd", safeGetString(rs, "processing_region_cd"));

        Timestamp businessTs = safeGetTimestamp(rs, "business_dt");
        if (businessTs != null) {
            m.put("business_dt", DATE_ONLY.format(new Date(businessTs.getTime())));
        } else {
            m.put("business_dt", safeGetString(rs, "business_dt"));
        }

        Timestamp startedTs = safeGetTimestamp(rs, "started");
        Timestamp completedTs = safeGetTimestamp(rs, "completed");
        if (startedTs != null) m.put("started", TS_FMT.format(startedTs.toInstant()));
        else m.put("started", safeGetString(rs, "started"));
        if (completedTs != null) m.put("completed", TS_FMT.format(completedTs.toInstant()));
        else m.put("completed", safeGetString(rs, "completed"));

        String durationStr = null;
        try {
            durationStr = rs.getString("duration");
        } catch (SQLException e) {
        }
        if (durationStr != null && !durationStr.trim().isEmpty()) {
            if (durationStr.toLowerCase().contains("years") || durationStr.toLowerCase().contains("mons") || durationStr.toLowerCase().contains("secs")) {
                durationStr = computeDurationFromTimestamps(startedTs, completedTs);
            } else {
                durationStr = normalizeToHHMMSS(durationStr);
            }
        } else {
            durationStr = computeDurationFromTimestamps(startedTs, completedTs);
        }
        m.put("duration", durationStr);

        return m;
    }

    private String computeDurationFromTimestamps(Timestamp start, Timestamp end) {
        if (start == null || end == null) return "00:00:00";
        long seconds = Duration.between(start.toInstant(), end.toInstant()).getSeconds();
        if (seconds < 0) seconds = 0;
        long hrs = seconds / 3600;
        long mins = (seconds % 3600) / 60;
        long secs = seconds % 60;
        return String.format("%02d:%02d:%02d", hrs, mins, secs);
    }

    private String normalizeToHHMMSS(String s) {
        s = s.trim();
        if (s.matches("^\\d{1,}:\\d{2}:\\d{2}.*")) {
            String[] parts = s.split("\\.", 2);
            return parts[0].length() == 7 || parts[0].length() == 8 ? parts[0] : padHMS(parts[0]);
        }
        return "00:00:00";
    }

    private String padHMS(String s) {
        String[] p = s.split(":");
        int h = Integer.parseInt(p[0]);
        int m = Integer.parseInt(p[1]);
        int sec = Integer.parseInt(p[2]);
        return String.format("%02d:%02d:%02d", h, m, sec);
    }

    private Timestamp safeGetTimestamp(ResultSet rs, String col) {
        try {
            return rs.getTimestamp(col);
        } catch (SQLException e) {
            return null;
        }
    }

    private String safeGetString(ResultSet rs, String col) {
        try {
            return rs.getString(col);
        } catch (SQLException e) {
            return null;
        }
    }

    private String readResourceSql(String path) {
        try (java.io.InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream(path)) {
            if (is == null) return "";
            java.util.Scanner s = new java.util.Scanner(is, java.nio.charset.StandardCharsets.UTF_8.name()).useDelimiter("\\A");
            return s.hasNext() ? s.next() : "";
        } catch (Exception e) {
            throw new RuntimeException("Failed to read resource SQL: " + path, e);
        }
    }
}
