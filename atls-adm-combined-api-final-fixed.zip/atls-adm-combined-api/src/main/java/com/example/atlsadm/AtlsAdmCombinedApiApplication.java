package com.example.atlsadm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AtlsAdmCombinedApiApplication {
    public static void main(String[] args) {
        SpringApplication.run(AtlsAdmCombinedApiApplication.class, args);
    }
}
