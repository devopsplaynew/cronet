package com.example.atlsadm.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class AdmDataSourceConfig {

    @Bean
    @ConfigurationProperties("spring.datasource.adm")
    public DataSourceProperties admDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean(name = "admDataSource")
    public DataSource admDataSource() {
        return admDataSourceProperties().initializeDataSourceBuilder().build();
    }

    @Bean(name = "admJdbcTemplate")
    @Primary
    public JdbcTemplate admJdbcTemplate(@Qualifier("admDataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }
}
