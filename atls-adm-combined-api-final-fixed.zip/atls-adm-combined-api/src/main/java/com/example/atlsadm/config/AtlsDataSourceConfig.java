package com.example.atlsadm.config;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

@Configuration
public class AtlsDataSourceConfig {

    @Bean
    @ConfigurationProperties("spring.datasource.atls")
    public DataSourceProperties atlsDataSourceProperties() {
        return new DataSourceProperties();
    }

    @Bean(name = "atlsDataSource")
    public DataSource atlsDataSource() {
        return atlsDataSourceProperties().initializeDataSourceBuilder().build();
    }

    @Bean(name = "atlsJdbcTemplate")
    public JdbcTemplate atlsJdbcTemplate(@Qualifier("atlsDataSource") DataSource ds) {
        return new JdbcTemplate(ds);
    }
}
