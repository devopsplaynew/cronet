package com.example.atlsadm.service;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Duration;
import java.util.*;

@Service
public class CombinedDataService {

    private final JdbcTemplate admJdbcTemplate;
    private final JdbcTemplate atlsJdbcTemplate;

    public CombinedDataService(@Qualifier("admJdbcTemplate") JdbcTemplate admJdbcTemplate,
                               @Qualifier("atlsJdbcTemplate") JdbcTemplate atlsJdbcTemplate) {
        this.admJdbcTemplate = admJdbcTemplate;
        this.atlsJdbcTemplate = atlsJdbcTemplate;
    }

    public Map<String, Object> getCombinedData() {
        String admQuery = new StringBuilder()
                .append("/* adm SQL from sql/adm.sql - simplified for API */")
                .toString();

        String atlsQuery = new StringBuilder()
                .append("/* atls SQL from sql/atls.sql - simplified for API */")
                .toString();

        List<Map<String, Object>> admData = admJdbcTemplate.query(admQuery, (rs, rowNum) -> mapRow(rs));
        List<Map<String, Object>> atlsData = atlsJdbcTemplate.query(atlsQuery, (rs, rowNum) -> mapRow(rs));

        Map<String, Object> combined = new HashMap<>();
        combined.put("admData", admData);
        combined.put("atlsData", atlsData);
        combined.put("timestamp", new Date());
        return combined;
    }

    private Map<String, Object> mapRow(ResultSet rs) throws SQLException {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("process_type", rs.getString("process_type"));
        m.put("client_cd", rs.getString("client_cd"));
        m.put("processing_region_cd", rs.getString("processing_region_cd"));
        m.put("business_dt", rs.getTimestamp("business_dt"));
        m.put("started", rs.getTimestamp("started"));
        m.put("completed", rs.getTimestamp("completed"));

        Object durationObj = null;
        try {
            durationObj = rs.getObject("duration");
        } catch (SQLException e) {
            // ignore if column not present
        }
        String formattedDuration = "00:00:00";
        if (durationObj != null) {
            formattedDuration = formatDurationFromString(durationObj.toString());
        }
        m.put("duration", formattedDuration);
        return m;
    }

    private String formatDurationFromString(String input) {
        // parse strings like "0 years 0 mons 0 days 0 hours 0 mins 29.047875 secs"
        int hours = 0, minutes = 0, seconds = 0;
        String[] parts = input.split("\s+");
        for (int i = 0; i < parts.length; i++) {
            if ("hours".equals(parts[i]) && i>0) {
                hours = Integer.parseInt(parts[i-1]);
            } else if ("mins".equals(parts[i]) && i>0) {
                minutes = Integer.parseInt(parts[i-1]);
            } else if ("secs".equals(parts[i]) && i>0) {
                double secd = Double.parseDouble(parts[i-1]);
                seconds = (int) Math.round(secd);
            }
        }
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }
}