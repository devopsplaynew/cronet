-- ATLS query (EOD/SOD/ARS)
WITH markers AS (
    SELECT 
        client_cd, 
        processing_region_cd, 
        business_dt::timestamp AS business_dt, 
        trigger_marker_type_cd, 
        MAX(created_at) AS created_ts, 
        MAX(updated_at) AS updated_ts
    FROM ars_events
    WHERE trigger_marker_type_cd IN (
        'opsRegionEodSignoff', 
        'accountingRegionEodClose', 
        'sodRegionGlobalProcessTrigger', 
        'accountingRegionSodDone'
    )
    GROUP BY client_cd, processing_region_cd, business_dt, trigger_marker_type_cd
),

start_times AS (
    SELECT 
        snapshot_type_cd, 
        client_cd, 
        processing_region_cd, 
        business_dt::timestamp AS business_dt, 
        MIN(created_at) AS started
    FROM accounting_events
    WHERE business_dt >= '2025-10-01'
    GROUP BY snapshot_type_cd, client_cd, processing_region_cd, business_dt
),

end_times AS (
    SELECT 
        ae.snapshot_type_cd, 
        ae.client_cd, 
        ae.processing_region_cd, 
        ae.business_dt::timestamp AS business_dt, 
        MAX(m.created_at) AS completed
    FROM markers m
    JOIN accounting_events ae 
        ON m.accounting_event_id = ae.id
    WHERE ae.business_dt >= '2025-10-01' 
      AND m.marker_type LIKE 'RegionSubjectAreaTransformed'
    GROUP BY ae.snapshot_type_cd, ae.client_cd, ae.processing_region_cd, ae.business_dt
)

-- EOD Process
SELECT
    'EODARS' AS process_type,
    eod.client_cd,
    eod.processing_region_cd,
    eod.business_dt,
    eod.created_ts AS started,
    eod_close.updated_ts AS completed,
    TO_CHAR((eod_close.updated_ts - eod.created_ts), 'HH24:MI:SS') AS duration
FROM markers eod
JOIN markers eod_close 
    ON eod.client_cd = eod_close.client_cd
   AND eod.processing_region_cd = eod_close.processing_region_cd
   AND eod.business_dt = eod_close.business_dt
WHERE eod.trigger_marker_type_cd = 'opsRegionEodSignoff'
  AND eod_close.trigger_marker_type_cd = 'accountingRegionEodClose'

UNION ALL

-- SOD Process
SELECT
    'SODARS' AS process_type,
    sod.client_cd,
    sod.processing_region_cd,
    sod.business_dt,
    sod.created_ts AS started,
    sod_done.updated_ts AS completed,
    TO_CHAR((sod_done.updated_ts - sod.created_ts), 'HH24:MI:SS') AS duration
FROM markers sod
JOIN markers sod_done 
    ON sod.client_cd = sod_done.client_cd
   AND sod.processing_region_cd = sod_done.processing_region_cd
   AND sod.business_dt = sod_done.business_dt
WHERE sod.trigger_marker_type_cd = 'sodRegionGlobalProcessTrigger'
  AND sod_done.trigger_marker_type_cd = 'accountingRegionSodDone'

UNION ALL

-- Snapshot processes
SELECT
    s.snapshot_type_cd AS process_type,
    s.client_cd,
    s.processing_region_cd,
    s.business_dt,
    s.started,
    e.completed,
    TO_CHAR((e.completed - s.started), 'HH24:MI:SS') AS duration
FROM start_times s
JOIN end_times e 
    ON s.snapshot_type_cd = e.snapshot_type_cd
   AND s.client_cd = e.client_cd
   AND s.processing_region_cd = e.processing_region_cd
   AND s.business_dt = e.business_dt;
