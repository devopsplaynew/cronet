package com.most.adu.cronet;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CronetApplication {

	public static void main(String[] args) {
		SpringApplication.run(CronetApplication.class, args);
	}

}
