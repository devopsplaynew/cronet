package com.most.adu.cronet.repository;

import com.most.adu.cronet.model.Registeration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface JpaRepo extends JpaRepository<Registeration,Integer> {
}
