package com.most.adu.cronet.service;

import com.most.adu.cronet.model.Registeration;
import com.most.adu.cronet.repository.JpaRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class StudentService {
    @Autowired
    JpaRepo jpa;
    public Registeration addData(Registeration regi)
    {
       return this.jpa.save(regi);
    }
    public Optional<Registeration> getRecord(Integer id)
    {
        return this.jpa.findById(id);
    }
}
