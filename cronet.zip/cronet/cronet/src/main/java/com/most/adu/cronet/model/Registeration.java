package com.most.adu.cronet.model;


import jakarta.persistence.*;

@Entity
@Table(name="student_registeration")
public class Registeration {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    @Column(name="student_id")
    private int StudentId;
    @Column(name="student_name")
    private String name;
    @Column(name="department_name")
    private String Department;
    @Column(name="address_student")
    private String Address;

    public int getStudentId() {
        return StudentId;
    }

    public void setStudentId(int studentId) {
        StudentId = studentId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return Department;
    }

    public void setDepartment(String department) {
        Department = department;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }
}
