package com.most.adu.cronet.controllerPgm;

import com.most.adu.cronet.model.Registeration;
import com.most.adu.cronet.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/homepage")
public class HomeController {
    @Autowired
    StudentService studentService;
    @PostMapping("/registeration")
    public Registeration addValues(@RequestBody Registeration regi)
    {
        return this.studentService.addData(regi);
    }

    @GetMapping("/Getrecords/{id}")
    public Optional<Registeration> getRecord(@PathVariable (value = "id") Integer id)
    {
        return this.studentService.getRecord(id);
    }
}
