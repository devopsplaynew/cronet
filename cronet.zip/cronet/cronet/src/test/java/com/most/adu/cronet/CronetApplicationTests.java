package com.most.adu.cronet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CronetApplicationTests {

	@Test
	void contextLoads() {
	}

}
